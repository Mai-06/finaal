/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectonuevo;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dominio.Usuario;
import conexion.Conexion;

/**
 *
 * @author Yasmin
 */
public class Proyectonuevo {

	/**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        // SE INSTANCIA LA CLASE CONEXION 
    	Conexion conexion = new Conexion();
    	
    	// DECLARAR UN OBJET PARA LA CONEXION
    	Connection con = null;
    	
    	// DECLARAR UN OBJETO PARA LAS CONSULTAS SQL
    	Statement stm = null;
    	
    	// DECLARAR UN OBJETO PARA GUARDAR LOS RESULTADOS DE LAS CONSULTAS SQL
    	ResultSet rs = null; 
    	
    	// SE CARGA EL CONTROLADOR
    	conexion.setControler();
    	
    	try {
    		// SE ESTABLECE LA CONEXION Y SE GUARDA EN UN OBJETO TIPO CONNECTION
        	con = conexion.conectar();
        	
    		// SE CREA EL OBJETO PARA LAS SENTENCIAS SQL
        	stm = con.createStatement();
        	
        	// VARIABLE CON LA CONSULTA A LA TABLA USUARIO
        	String str = "SELECT * FROM USUARIO";
        	
        	rs = stm.executeQuery(str);
        	
        	// SE CREA UNA LISTA DE USUARIO PARA GUARDAR LOS RESULTADOS
        	List<Usuario> listaUsuarios = new ArrayList<Usuario>();
        	
        	// MOSTRAR EL RESULTADO - SE RECORREN LOS REGISTROS
        	while(rs.next()) {
        		// SE DECLARA UN OBJETO DE TIPO USUARIO
        		Usuario  usuario = new Usuario();
        		
        		// SE ALMACENAN LOS RESULTADOS
        		usuario.setId(rs.getInt(1));
        		usuario.setLogin(rs.getString(2));
        		usuario.setEmail(rs.getString(3));
        		usuario.setUltimoAcceso(rs.getDate(6));
        		
        		// SE GUARDA EL OBJETO EN LA LISTA
        		listaUsuarios.add(usuario);
        	}
        	
        	for (Iterator<Usuario> iterator = listaUsuarios.iterator(); iterator.hasNext();) {
				Usuario usuario = (Usuario) iterator.next();
				String fecha = new SimpleDateFormat("dd/MM/yyyy").format( usuario.getUltimoAcceso());
				System.out.println("Para el usuario:" + usuario.getLogin() + ". Con correo: " + usuario.getEmail() + ". Ingres� por �ltima vez: " + fecha);
			}
    	}catch (SQLException e) {
		} finally {
			// SE CIERRAN LAS CONEXIONES
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
			};
			try {
				if (stm != null)
					stm.close();
			} catch (Exception e) {
			};
			try {
				if (con != null)
					con.close();
			} catch (Exception e) {
			};
		}
    }
}
