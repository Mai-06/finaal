
package dominio; 

import java.util.List;

/**
 *
 * @author Yasmin
 */
 public class AdministradorHotel {
	private String nombre;
	private String apellidos;
	private List<Hotel> listaHoteles;
	
	public AdministradorHotel() {
		
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public List<Hotel> getListaHoteles() {
		return listaHoteles;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	public void setListaHoteles(List<Hotel> listaHoteles) {
		this.listaHoteles = listaHoteles;
	}
			
}