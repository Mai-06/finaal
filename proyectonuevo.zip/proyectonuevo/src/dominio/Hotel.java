package dominio; 

import java.util.List;

/**
 *
 * @author Yasmin
 */
 public class Hotel {		
	private Integer id;
	private String nombre;
	private String descripcion;
	private String categoria;
	private String domocilio;
	private String poblacion;
	private String provincia;
	private String codPostal;
	private String telefono;
	private String administrador;
	private List<TipoHabitacion> tiposHabitacion;
	
	public Hotel() {
		
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public String getCategoria() {
		return categoria;
	}
	
	public String getDomocilio() {
		return domocilio;
	}
	
	public String getPoblacion() {
		return poblacion;
	}
	
	public String getProvincia() {
		return provincia;
	}
	
	public String getCodPostal() {
		return codPostal;
	}
	
	public String getTelefono() {
		return telefono;
	}
	
	public String getAdministrador() {
		return administrador;
	}
	
	public List<TipoHabitacion> getTiposHabitacion() {
		return tiposHabitacion;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	public void setDomocilio(String domocilio) {
		this.domocilio = domocilio;
	}
	
	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}
	
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	
	public void setCodPostal(String codPostal) {
		this.codPostal = codPostal;
	}
	
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	public void setAdministrador(String administrador) {
		this.administrador = administrador;
	}
	
	public void setTiposHabitacion(List<TipoHabitacion> tiposHabitacion) {
		this.tiposHabitacion = tiposHabitacion;
	}
			
}