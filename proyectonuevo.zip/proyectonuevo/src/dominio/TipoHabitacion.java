package dominio; 

/**
 *
 * @author Yasmin
 */
 public class TipoHabitacion {
	private int id;
	private String nombre;
	private String descripcion;
	private String capacidad;
	private Float precio;
	private Integer idHotel;
	
	public TipoHabitacion() {
		
	}

	public int getId() {
		return id;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	
	
	public String getDescripcion() {
		return descripcion;
	}
	
	
	public String getCapacidad() {
		return capacidad;
	}
	
	
	public Float getPrecio() {
		return precio;
	}
	
	public Integer getIdHotel() {
		return idHotel;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setCapacidad(String capacidad) {
		this.capacidad = capacidad;
	}
	
	public void setPrecio(Float precio) {
		this.precio = precio;
	}
	
	public void setIdHotel(Integer idHotel) {
		this.idHotel = idHotel;
	}
	
	
	
}