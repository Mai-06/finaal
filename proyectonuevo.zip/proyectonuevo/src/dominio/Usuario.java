package dominio; 

import java.util.Date;

/**
 *
 * @author Yasmin
 */
 public class Usuario {
	private int id;
	private String login;
	private String password;
	private String email;
	private Date fechaAlta;
	private Date ultimoAcceso;

	public Usuario() {
		
	}

	public int getId() {
		return id;
	}

	public String getLogin() {
		return login;
	}

	public String getPassword() {
		return password;
	}

	public String getEmail() {
		return email;
	}

	public Date getFechaAlta() {
		return fechaAlta;
	}

	public Date getUltimoAcceso() {
		return ultimoAcceso;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFechaAlta(Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}

	public void setUltimoAcceso(Date ultimoAcceso) {
		this.ultimoAcceso = ultimoAcceso;
	}
	
}