package dominio; 

/**
 *
 * @author Yasmin
 */
 public class Cliente {
	private Integer id;
	private String nombre;
	private String apellidos;
	private String nit; 
	private String domicilio;
	private String poblacion;
	private String provincia;
	private String codPostal;
	
	public Cliente() {
		
	}
	
	public Integer getId() {
		return id;
	}
	
	public String getNombre() {
		return nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public String getNit() {
		return nit;
	}

	public String getDomicilio() {
		return domicilio;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public String getProvincia() {
		return provincia;
	}

	public String getCodPostal() {
		return codPostal;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public void setDomicilio(String domicilio) {
		this.domicilio = domicilio;
	}

	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public void setCodPostal(String codPostal) {
		this.codPostal = codPostal;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	private String telefono;
	
	
	
	

	
}