package dominio; 

import java.util.Date;

/**
 *
 * @author Yasmin
 */
 public class Reserva {
	private int id;	
	private Date fechaInicio;
	private Date fechaFin;
	private Float precio;
	private String ocupacion;
	private String nombreNomenclador;
	private Integer idCliente;
	private Integer idTipoHabitacion;
	
	public Reserva() {
		
	}
	
	public int getId() {
		return id;
	}
	
	public Date getFechaInicio() {
		return fechaInicio;
	}
	
	public Date getFechaFin() {
		return fechaFin;
	}
	
	public Float getPrecio() {
		return precio;
	}
	
	public String getOcupacion() {
		return ocupacion;
	}
	
	public String getNombreNomenclador() {
		return nombreNomenclador;
	}
	
	public Integer getIdCliente() {
		return idCliente;
	}
	
	public Integer getIdTipoHabitacion() {
		return idTipoHabitacion;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	public void setPrecio(Float precio) {
		this.precio = precio;
	}
	
	public void setOcupacion(String ocupacion) {
		this.ocupacion = ocupacion;
	}
	
	public void setNombreNomenclador(String nombreNomenclador) {
		this.nombreNomenclador = nombreNomenclador;
	}
	
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	
	public void setIdTipoHabitacion(Integer idTipoHabitacion) {
		this.idTipoHabitacion = idTipoHabitacion;
	}
		
}