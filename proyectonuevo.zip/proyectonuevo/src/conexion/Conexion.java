package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
	
	private static final String CONTROLADOR = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/hoteleria?characterEncoding=latin1";
	private static final String USUARIO = "root";
	private static final String CLAVE = "12345";
	
	/*
	 * M�todo encargado de cargar el driver de MYSQL
	 * */
	public void setControler() {
		try {
			// CARGAR EL DRIVER PARA MYSQL
			Class.forName(CONTROLADOR);
		} catch (ClassNotFoundException e) {
			System.out.println("Hubo un error al cargar controlador: com.mysql.jdbc.Driver.");
			e.printStackTrace();
		}
	}
	
	/*
	 * M�todo encargado de establecer la conexi�n con la BD HOTELERIA
	 * */
	public Connection conectar() {
		Connection conexion = null;
		
		try {
			// ESTABLECER LA CONEXION CON LA BD
			conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);
			System.out.println("Establecida la conexi�n...");
		} catch (SQLException e) {
			System.out.println("Hubo un error al establecer la conexi�n con la bd en mysql.");
			e.printStackTrace();
		}
		return conexion;
	}
	
}
